document.addEventListener("DOMContentLoaded", () => {
  const urlParams = new URLSearchParams(window.location.search);
  const category = urlParams.get('category');

  const productList = document.getElementById("productList");
  const filter = document.getElementById("priceFilter");

  function displayProducts(filteredProducts) {
    productList.innerHTML = "";
    filteredProducts.forEach(p => {
      const card = document.createElement("div");
      card.className = "product-card";
      card.innerHTML = `
        <img src="${p.image}" alt="${p.name}" />
        <h3>${p.name}</h3>
        <p>₹${p.price}</p>
      `;
      productList.appendChild(card);
    });
  }

  function filterProducts() {
    let filtered = products.filter(p => p.category === category);
    const selectedFilter = filter.value;

    if (selectedFilter === "0-1000") {
      filtered = filtered.filter(p => p.price <= 1000);
    } else if (selectedFilter === "1000-5000") {
      filtered = filtered.filter(p => p.price > 1000 && p.price <= 5000);
    } else if (selectedFilter === "5000+") {
      filtered = filtered.filter(p => p.price > 5000);
    }

    displayProducts(filtered);
  }

  filter.addEventListener("change", filterProducts);

  filterProducts(); // Initial load
});

function addToCart(name, price) {
  cart.push({ name, price });
  updateCart();
}

function updateCart() {
  const cartList = document.getElementById('cart-items');
  const cartTotal = document.getElementById('cart-total');
  cartList.innerHTML = '';
  let total = 0;
  cart.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `\${item.name} - ₹\${item.price}`;
    cartList.appendChild(li);
    total += item.price;
  });
  cartTotal.textContent = total;
}

window.onload = loadProducts;


