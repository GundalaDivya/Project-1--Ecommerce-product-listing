const products = [
  {
    id: 1,
    name: "Smartphone",
    price: 15000,
    category: "electronics",
    image: "images/smartphone.jpg",
    description: "Latest 5G smartphone with great features"
  },
  {
    id: 2,
    name: "Headphones",
    price: 2500,
    category: "electronics",
    image: "images/headphones.jpg",
    description: "Noise-cancelling over-ear headphones"
  },
  {
    id: 3,
    name: "T-shirt",
    price: 499,
    category: "clothing",
    image: "images/tshirt.jpg",
    description: "Comfortable cotton t-shirt"
  },
  {
    id: 4,
    name: "Wrist Watch",
    price: 2999,
    category: "accessories",
    image: "images/watch.jpg",
    description: "Stylish waterproof wristwatch"
  },
  {
    id: 5,
    name: "Jeans",
    price: 1099,
    category: "clothing",
    image: "images/jeans.jpg",
    description: "Slim-fit stretchable jeans"
  }
];
